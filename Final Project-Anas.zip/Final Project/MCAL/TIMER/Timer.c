#include "Timer.h"

#define msPerOV 262;	// Time in ms per overflow (When using a 1024 prescalar)

void Timer_init(uint8_t mode, uint8_t OCR_Val){				// Could use macros for the CS mode bits
	switch(mode){
		case 0:
		TCCR0 &= ~(0x48);
		break;
		case 1:
		TCCR0 |= (1<<6);
		TCCR0 &= ~(1<<3);
		break;
		case 2:
		TCCR0 |= (1<<3);
		TCCR0 &= ~(1<<6);
		OCR0 = OCR_Val;
		break;
		case 3:
		TCCR0 |= (0x48);
		break;
	}
	}
	
	void Timer_start(uint8_t Prescale){
		TCCR0 &= ~(0x07);
		TCCR0 |= Prescale;
		}
	
	void Timer_stop(){			
		TCCR0 &= ~(0x07);
		};
		
	void Timer_setValue(uint8_t val){
		TCNT0 = val;
		};
		
	uint8_t get_state(){							// Returns the T0 flag bits
		return TIFR & 0x03;
		};
		
	void Timer_resetFlags(){						// Resets the overflow and OCR flag
		TIFR |= (0x03);
	}
	
	void Timer_delayms(uint16_t ms){
		uint8_t OVCount = ms/msPerOV;				// Number of overflows to go through
		uint8_t OVRmndr = ms % msPerOV;				// What remains after going through the overflows
		
		Timer_resetFlags();
		Timer_start(CLK1024);
		Timer_setValue(0);
		
		while(OVCount> 0){
			
			while((TIFR & 0x01) == 0);				// While overflow not reached
			
			Timer_resetFlags();						// Reset timer
			Timer_setValue(0);
			OVCount--;
		}
		
		Timer_setValue(256-OVRmndr);				
		while((TIFR & (1 << OVFlag)) == 0);
		Timer_resetFlags();
	}