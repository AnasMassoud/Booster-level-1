#pragma once
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\registers.h"

// These values are given as the first argument to Timer_init 
#define T_NORMAL 0
#define T_PWM 1
#define T_CTC 2
#define T_FPWM 3

// These are given to Timer_start, determines the prescalar
#define CLK1 1
#define CLK8 2
#define CLK64 3
#define CLK256 4
#define CLK1024 5


#define T0FE 6
#define T0RE 7
#define OVFlag 0
#define OCRFlag 1


// Initiates timer with specific mode and OCR value. If you're not using the OCR, use 0 as an argument for the OCR_Val
void Timer_init(uint8_t mode, uint8_t OCR_Val);

// Starts the timer with a prescalar as an argument
void Timer_start(uint8_t Prescale);

// Stops the timer
void Timer_stop();

// Sets a timer value
void Timer_setValue(uint8_t val);

// Delays ms seconds
void Timer_delayms(uint16_t val);

// Resets timer flags
void Timer_resetFlags();

// Returns the timer's flag bit values
uint8_t get_state();
