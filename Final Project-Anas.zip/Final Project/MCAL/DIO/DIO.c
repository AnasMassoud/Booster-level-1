#include "DIO.h"

void Dio_Init(uint8_t PortName, uint8_t PinNum, uint8_t Direction)
{
	if (PortName == 'A')
	{
		if (Direction == output)
		{
			PA_CONTROL |= (1<<PinNum);
		}
		else
		{
			PA_CONTROL &= ~(1<<PinNum);
		}
	}
	
	else if (PortName == 'B')
	{
		if (Direction == output)
		{
			PB_CONTROL |= (1<<PinNum);
		}
		else
		{
			PB_CONTROL &= ~(1<<PinNum);
		}
	}
	
	else if (PortName == 'C')
	{
		if (Direction == output)
		{
			PC_CONTROL |= (1<<PinNum);
		}
		else
		{
			PC_CONTROL &= ~(1<<PinNum);
		}
	}
	
	else
	{
		if (Direction == output)
		{
			PD_CONTROL |= (1<<PinNum);
		}
		else
		{
			PD_CONTROL &= ~(1<<PinNum);
		}
	}
}


void Dio_Write(uint8_t PortName, uint8_t PinNum, uint8_t Data)
{
	if (PortName == 'A')
	{
		if (Data == high)
		{
			PA_DATA |= (1<<PinNum);
		}
		else
		{
			PA_DATA &= ~(1<<PinNum);
		}
	}
	
	else if (PortName == 'B')
	{
		if (Data == high)
		{
			PB_DATA |= (1<<PinNum);
		}
		else
		{
			PB_DATA &= ~(1<<PinNum);
		}
	}
	
	else if (PortName == 'C')
	{
		if (Data == high)
		{
			PC_DATA |= (1<<PinNum);
		}
		else
		{
			PC_DATA &= ~(1<<PinNum);
		}
	}
	
	else
	{
		if (Data == high)
		{
			PD_DATA |= (1<<PinNum);
		}
		else
		{
			PD_DATA &= ~(1<<PinNum);
		}
	}
}

//this function reads status of specific pin, if pin equals zero function returns zero, if pin equal 1 it returns value that is not equal to zero. 
uint8_t Dio_Read(uint8_t PortName, uint8_t PinNum)
{
	if (PortName == 'A')
	{
		return (PA_STATUS & (1<<PinNum));
	}
	else if (PortName == 'B')
	{
		return (PB_STATUS & (1<<PinNum));
	}
	else if (PortName == 'C')
	{
		return (PC_STATUS & (1<<PinNum));
	}
	else 
	{
		return (PD_STATUS & (1<<PinNum));
	}
}