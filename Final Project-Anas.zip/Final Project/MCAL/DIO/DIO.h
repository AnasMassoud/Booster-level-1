#ifndef DIO_H_
#define DIO_H_

#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\registers.h"

enum DataDirection
{
	input = 0,
	output= 1
};

enum DataValue
{
	low=0,
	high=1
};

void Dio_Init(uint8_t PortName, uint8_t PinNum, uint8_t Direction);

void Dio_Write(uint8_t PortName, uint8_t PinNum, uint8_t Data);

uint8_t Dio_Read(uint8_t PortName, uint8_t PinNum);

#endif /* DIO_H_ */