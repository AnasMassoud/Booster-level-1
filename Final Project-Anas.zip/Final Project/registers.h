#ifndef _REGISTERS_H_
#define _REGISTERS_H_

#include "D:\3rdCSE\Me\Sprints Embedded Booster\types.h"

#define PA_DATA *((volatile ptochar_t)(0x3B))
#define PA_CONTROL *((volatile ptochar_t)(0x3A))
#define PA_STATUS *((volatile ptochar_t)(0x39))
#define PB_DATA *((volatile ptochar_t)(0x38))
#define PB_CONTROL *((volatile ptochar_t)(0x37))
#define PB_STATUS *((volatile ptochar_t)(0x36))
#define PC_DATA *((volatile ptochar_t)(0x35))
#define PC_CONTROL *((volatile ptochar_t)(0x34))
#define PC_STATUS *((volatile ptochar_t)(0x33))
#define PD_DATA *((volatile ptochar_t)(0x32))
#define PD_CONTROL *((volatile ptochar_t)(0x31))
#define PD_STATUS *((volatile ptochar_t)(0x30))
#define STATUS_REG *((volatile ptochar_t)(0x5F))
#define TCCR0 *((volatile uint8_t*)(0x53))
#define TCNT0 *((volatile uint8_t*)(0x52))
#define OCR0 *((volatile uint8_t*)(0x5C))
#define TIFR *((volatile uint8_t*)(0x58))
#define TIMSK *((volatile uint8_t*)(0x59))
#define TCCR2 *((volatile uint8_t*)(0x45))
#define TCNT2 *((volatile uint8_t*)(0x44))
#define OCR2 *((volatile uint8_t*)(0x43))
#define GICR *((volatile uint8_t*)(0x5B))
#define MCUCSR *((volatile uint8_t*)(0x54))


#endif