/*
 * BUTTON.c
 *
 * Created: 8/25/2020 2:19:23 AM
 *  Author: Lenovo
 */ 
#include "BUTTON.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\MCAL\DIO\DIO.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\MCAL\TIMER\Timer.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\interrupts.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\ECUAL\MOTOR\MOTOR.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\ECUAL\LED\LED.h"
uint8_t speed = 0;
void BUTTON_init (uint8_t button)
{
	if (button == BUTTON1)
	  Dio_Init('B',0,low);
	else if (button == BUTTON2)
	  Dio_Init('B',1,low);
	else if (button == BUTTON3)
	{
		Dio_Init('B',2,low);
	    STATUS_REG |= (1<<7);                //enable for global interrupt.
	    GICR |= (1<<5);                      // enable for external INT2.
	    MCUCSR |= (1<<6);                    // sense rising edge on INT2 pin to generate interrupt.
	}
	else if (button == BUTTON4)
	  Dio_Init('B',3,low);
}
uint8_t BUTTON_status (uint8_t button)
{
	if (button == BUTTON1)
	return Dio_Read('B',0);
	
	else if (button == BUTTON2)
	return Dio_Read('B',1);
	
	else if (button == BUTTON3)
	return Dio_Read('B',2);
	
	else if (button == BUTTON4)
	return Dio_Read('B',3);
		
	else
	return 0;
}
void __vector_3(void)
{
	if (speed == 0)
	  {
		  speed = SPEED1;
		  LED_set(LED1,ON);
	  }
	else if (speed == SPEED1)
	  {
		  speed = SPEED2;
		  LED_set(LED1,OFF);
		  LED_set(LED2,ON);
	  }
	else if (speed == SPEED2)
	  {
		  speed = SPEED3;
		  LED_set(LED2,OFF);
		  LED_set(LED3,ON);
	  }
	else if (speed == SPEED3)
	  {
		  speed = BACKWARD;
		  LED_set(LED3,OFF);
		  LED_set(LED4,ON);
	  }
	else if (speed == BACKWARD)
	  {
		  speed = SPEED1;
		  LED_set(LED4,OFF);
		  LED_set(LED1,ON);
	  }
}
