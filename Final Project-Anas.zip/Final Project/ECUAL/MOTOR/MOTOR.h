/*
 * MOTOR.h
 *
 * Created: 9/13/2020 9:11:23 PM
 *  Author: Lenovo
 */ 


#ifndef MOTOR_H_
#define MOTOR_H_
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\registers.h"


#define MOTOR1 1
#define MOTOR2 2
#define MOTOR3 3
#define MOTOR4 4

#define SPEED1 1
#define SPEED2 2
#define SPEED3 3
#define BACKWARD 4

#define RIGHT 5
#define LEFT 6

extern uint8_t speed;

typedef enum M_STATUS
{
	M_OFF,
	M_ON
}M_STATUS;

typedef enum M_DIR
{
	BWD,
	FWD
}M_DIR;

void MOTOR_speed (uint8_t speed);
void MOTOR_init (uint8_t motor);
void MOTOR_set (uint8_t motor,M_STATUS stat, M_DIR dir);
uint8_t MOTOR_status(uint8_t motor);
void MOTOR_toggle (uint8_t motor);
void MOTOR_left();
void MOTOR_right();



#endif /* MOTOR_H_ */