/*
 * MOTOR.c
 *
 * Created: 9/13/2020 9:11:39 PM
 *  Author: Lenovo
 */ 
#include "MOTOR.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\MCAL\DIO\DIO.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\MCAL\TIMER\Timer.h"
void MOTOR_init (uint8_t motor)
{
	if (motor == MOTOR1)
	{
		Dio_Init('D',0,output);
		Dio_Init('D',1,output);
	}
	if (motor == MOTOR2)
	{
		Dio_Init('D',2,output);
		Dio_Init('D',3,output);
	}

}
void MOTOR_set (uint8_t motor,M_STATUS stat,M_DIR dir)
{
	if (motor == MOTOR1)
	{
		if (stat == M_ON)
		
		{			if(dir == FWD)
			{
				Dio_Write('D',0,high);
				Dio_Write('D',1,low);
			}
			else if (dir == BWD)
			{
				Dio_Write('D',1,high);
				Dio_Write('D',0,low);
			}

			
		}
		else if (stat == M_OFF)
		{
			Dio_Write('D',0,low);
			Dio_Write('D',1,low);
		}
	}
	else if (motor == MOTOR2)
	{
		if (stat == M_ON)
		{
			if(dir == FWD)
			{
				Dio_Write('D',2,high);
				Dio_Write('D',3,low);
			}
			else if (dir == BWD)
			{
				Dio_Write('D',3,high);
				Dio_Write('D',2,low);
			}
		}
		else if (stat == M_OFF)
		{
			Dio_Write('D',2,low);
			Dio_Write('D',3,low);
		}
	}
	
}
uint8_t MOTOR_status(uint8_t motor)
{
	if (motor == MOTOR1)
	return Dio_Read('D',0);

	if (motor == MOTOR2)
	return Dio_Read('D',1);
	
	if (motor == MOTOR3)
	return Dio_Read('D',2);
	
	if (motor == MOTOR4)
	return Dio_Read('D',3);
	
	else
	return -1;
}
/*void MOTOR_toggle (uint8_t motor)
{
	if (motor == MOTOR1)
	DIO_toggle(PORTD,PIN0);
	
	if (motor == MOTOR2)
	DIO_toggle(PORTD,PIN1);
	
	if (motor == MOTOR3)
	DIO_toggle(PORTD,PIN2);
	
	if (motor == MOTOR4)
	DIO_toggle(PORTD,PIN3);
}*/

void MOTOR_speed (uint8_t speed)
{

	if (speed == SPEED1)
	{
		MOTOR_set(MOTOR1,M_ON,FWD);
		MOTOR_set(MOTOR2,M_ON,FWD);
		Timer_delayms(30);
		MOTOR_set(MOTOR1,M_OFF,FWD);
		MOTOR_set(MOTOR2,M_OFF,FWD);
		Timer_delayms(70);	
	}
	if (speed == SPEED2)
	{
		MOTOR_set(MOTOR1,M_ON,FWD);
		MOTOR_set(MOTOR2,M_ON,FWD);
		Timer_delayms(60);
		MOTOR_set(MOTOR1,M_OFF,FWD);
		MOTOR_set(MOTOR2,M_OFF,FWD);
		Timer_delayms(40);
	}
	if (speed == SPEED3)
	{
		MOTOR_set(MOTOR1,M_ON,FWD);
		MOTOR_set(MOTOR2,M_ON,FWD);
		Timer_delayms(90);
		MOTOR_set(MOTOR1,M_OFF,FWD);
		MOTOR_set(MOTOR2,M_OFF,FWD);
		Timer_delayms(10);
	}
	if (speed == BACKWARD)
	{
		MOTOR_set(MOTOR1,M_ON,BWD);
		MOTOR_set(MOTOR2,M_ON,BWD);
		Timer_delayms(30);
		MOTOR_set(MOTOR1,M_OFF,BWD);
		MOTOR_set(MOTOR2,M_OFF,BWD);
		Timer_delayms(70);
	}
} 

void MOTOR_right()
{
	MOTOR_set(MOTOR1,M_ON,BWD);
	MOTOR_set(MOTOR2,M_ON,FWD);
	Timer_delayms(30);
	MOTOR_set(MOTOR1,M_OFF,BWD);
	MOTOR_set(MOTOR2,M_OFF,FWD);
	Timer_delayms(70);
}

void MOTOR_left()
{
	MOTOR_set(MOTOR1,M_ON,FWD);
	MOTOR_set(MOTOR2,M_ON,BWD);
	Timer_delayms(30);
	MOTOR_set(MOTOR1,M_OFF,FWD);
	MOTOR_set(MOTOR2,M_OFF,BWD);
	Timer_delayms(70);
}