/*
 * LED.c
 *
 * Created: 8/25/2020 12:35:17 AM
 *  Author: Lenovo
 */ 

#include "LED.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\MCAL\DIO\DIO.h"
#include "c:\users\lenovo\Documents\Atmel Studio\7.0\Final Project\Final Project\MCAL\TIMER\Timer.h"

void LED_init (uint8_t led)
{
	if (led == LED1)
	{
		Dio_Init('C',0,output);
	}
	if (led == LED2)
	{
		Dio_Init('C',1,output);
	}
	else if (led == LED3)
	{
		Dio_Init('C',2,output);
	}
	else if (led == LED4)
	{
		Dio_Init('C',3,output);
	}
	
}
void LED_set (uint8_t led,STATUS stat)
{
	if (led == LED1)
	{
		if (stat == ON)
		  Dio_Write('C',0,high);
		else if (stat == OFF)
		  Dio_Write('C',0,low);
	}
	else if (led == LED2)
	{
		if (stat == ON)
		Dio_Write('C',1,high);
		else if (stat == OFF)
		Dio_Write('C',1,low);
	}
	else if (led == LED3)
	{
		if (stat == ON)
		Dio_Write('C',2,high);
		else if (stat == OFF)
		Dio_Write('C',2,low);
	}
	else if (led == LED4)
	{
		if (stat == ON)
		Dio_Write('C',3,high);
		else if (stat == OFF)
		Dio_Write('C',3,low);
	}
}
uint8_t LED_status(uint8_t led)
{
   if (led == LED1)
   return Dio_Read('C',0);

   if (led == LED2)
   return Dio_Read('C',1);
   
   if (led == LED3)
   return Dio_Read('C',0);
   
   if (led == LED4)
   return Dio_Read('C',2);
   
   else
   return -1;
}
/*void LED_toggle (uint8_t led)
{
   if (led == LED1)
   DIO_toggle(PORTA,PIN0);
   
   if (led == LED2)
   DIO_toggle(PORTA,PIN1);
   
   if (led == LED3)
   DIO_toggle(PORTA,PIN2);
   
   if (led == LED4)
   DIO_toggle(PORTA,PIN3);
}*/