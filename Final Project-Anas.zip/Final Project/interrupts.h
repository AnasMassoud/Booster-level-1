/*
 * interrupts.h
 *
 * Created: 9/12/2020 11:05:10 PM
 *  Author: Lenovo
 */ 


#ifndef INTERRUPTS_H_
#define INTERRUPTS_H_

void __vector_1(void) __attribute__ ((signal,used));
void __vector_2(void) __attribute__ ((signal,used));
void __vector_3(void) __attribute__ ((signal,used));
void __vector_4(void) __attribute__ ((signal,used));
void __vector_5(void) __attribute__ ((signal,used));
void __vector_6(void) __attribute__ ((signal,used));
void __vector_7(void) __attribute__ ((signal,used));
void __vector_8(void) __attribute__ ((signal,used));
void __vector_9(void) __attribute__ ((signal,used));
void __vector_10(void) __attribute__ ((signal,used));
void __vector_11(void) __attribute__ ((signal,used));
void __vector_12(void) __attribute__ ((signal,used));
void __vector_13(void) __attribute__ ((signal,used));
void __vector_14(void) __attribute__ ((signal,used));
void __vector_15(void) __attribute__ ((signal,used));
void __vector_16(void) __attribute__ ((signal,used));
void __vector_17(void) __attribute__ ((signal,used));
void __vector_18(void) __attribute__ ((signal,used));
void __vector_19(void) __attribute__ ((signal,used));
void __vector_20(void) __attribute__ ((signal,used));


#endif /* INTERRUPTS_H_ */