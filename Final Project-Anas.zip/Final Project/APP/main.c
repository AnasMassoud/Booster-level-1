/*
 * Final Project.c
 *
 * Created: 9/15/2020 5:57:20 PM
 * Author : Lenovo
 */ 
#include "MCAL/DIO/DIO.h"
#include "MCAL/TIMER/Timer.h"
#include "ECUAL/LED/LED.h"
#include "ECUAL/BUTTON/BUTTON.h"
#include "ECUAL/MOTOR/MOTOR.h"
#include "ECUAL/KEYPAD/KEYPAD.h"
extern uint8_t speed ;
int main(void)
{
	MOTOR_init(MOTOR1);
	MOTOR_init(MOTOR2);
	LED_init(LED1);
	LED_init(LED2);
	LED_init(LED3);
	LED_init(LED4);
	BUTTON_init(BUTTON1);
    BUTTON_init(BUTTON2);
	BUTTON_init(BUTTON3);
	BUTTON_init(BUTTON4);
    /* Replace with your application code */
    while (1) 
    {
       while (BUTTON_status(BUTTON1))
       {
	       MOTOR_speed(speed);
       }
       while (BUTTON_status(BUTTON2))
       {
	       MOTOR_right();
       }
       while (BUTTON_status(BUTTON4))
       {
	       MOTOR_left();
       }
    }
}

